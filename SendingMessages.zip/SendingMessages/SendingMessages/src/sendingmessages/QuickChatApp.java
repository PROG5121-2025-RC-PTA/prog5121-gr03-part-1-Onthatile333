package sendingmessages;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class QuickChatApp extends JFrame {

    // Fields for login
    static String allLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    static String allDigits = "0123456789";
    static String setRegistrationUsername;
    static String setRegistrationPassword;
    static String setRegistrationNumber;

    // GUI fields
    private JTextField idField, phoneField;
    private JTextArea messageArea, outputArea;
    private JButton sendButton, viewButton, clearButton;

    // Constructor - GUI setup
    public QuickChatApp() {
        setTitle("QuickChat App");
        setSize(600, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel contentPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                GradientPaint gradient = new GradientPaint(0, 0, new Color(255, 102, 102), 0, getHeight(), new Color(102, 204, 255));
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        contentPanel.setLayout(new BorderLayout());
        setContentPane(contentPanel);

        JPanel inputPanel = new JPanel(new GridLayout(6, 1, 5, 5));
        inputPanel.setBackground(new Color(255, 255, 255, 180));
        inputPanel.setBorder(BorderFactory.createTitledBorder("Send New Message"));

        idField = new JTextField();
        phoneField = new JTextField();
        messageArea = new JTextArea(3, 20);
        messageArea.setLineWrap(true);
        messageArea.setWrapStyleWord(true);
        JScrollPane messageScroll = new JScrollPane(messageArea);

        inputPanel.add(new JLabel("Message ID (max 10 chars):"));
        inputPanel.add(idField);
        inputPanel.add(new JLabel("Recipient Cell (+1234567890):"));
        inputPanel.add(phoneField);
        inputPanel.add(new JLabel("Message Content (max 250 chars):"));
        inputPanel.add(messageScroll);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(255, 255, 255, 180));
        sendButton = new JButton("Send Message");
        viewButton = new JButton("View Sent Messages");
        clearButton = new JButton("Clear Fields");
        buttonPanel.add(sendButton);
        buttonPanel.add(viewButton);
        buttonPanel.add(clearButton);

        outputArea = new JTextArea();
        outputArea.setEditable(false);
        outputArea.setLineWrap(true);
        outputArea.setWrapStyleWord(true);
        JScrollPane outputScroll = new JScrollPane(outputArea);
        outputScroll.setBorder(BorderFactory.createTitledBorder("Message Log"));

        contentPanel.add(inputPanel, BorderLayout.NORTH);
        contentPanel.add(buttonPanel, BorderLayout.CENTER);
        contentPanel.add(outputScroll, BorderLayout.SOUTH);

        sendButton.addActionListener(e -> sendMessage());
        viewButton.addActionListener(e -> viewMessages());
        clearButton.addActionListener(e -> clearFields());

        setVisible(true);
    }

    // Message sending logic
    private void sendMessage() {
        String id = idField.getText().trim();
        String phone = phoneField.getText().trim();
        String content = messageArea.getText().trim();

        Message msg = new Message(id, phone, content);

        if (!msg.checkMessageID()) {
            outputArea.append("❌ Invalid Message ID (max 10 characters).\n");
            return;
        }
        if (!msg.checkRecipientCell()) {
            outputArea.append("❌ Invalid Recipient Cell (must start with + and be numeric).\n");
            return;
        }
        if (!msg.checkMessageLength()) {
            outputArea.append("❌ Message exceeds 250 characters.\n");
            return;
        }

        Message.storeMessage(msg);
        outputArea.append("✅ " + msg.sendMessage() + "\n");
    }

    private void viewMessages() {
        outputArea.append("\n📨 Sent Messages:\n");
        if (Message.getMessagesSent().isEmpty()) {
            outputArea.append("No messages sent yet.\n");
        } else {
            for (Message m : Message.getMessagesSent()) {
                outputArea.append("ID: " + m.getMessageID()
                        + ", To: " + m.getRecipientCell()
                        + ", Hash: " + m.getMessageHash()
                        + ", Message: " + m.getMessageContent() + "\n");
            }
        }
    }

    private void clearFields() {
        idField.setText("");
        phoneField.setText("");
        messageArea.setText("");
    }

    // -------- LOGIN LOGIC BELOW --------

    static boolean checkUsername(String username) {
        if ((username.contains("_")) && (username.length() <= 5)) {
            JOptionPane.showMessageDialog(null, "Welcome " + username + ", it's great to see you.");
            return true;
        }
        JOptionPane.showMessageDialog(null, "Username is not correctly formatted. It must contain an underscore and be no more than 5 characters.");
        return false;
    }

    static boolean checkPasswordComplexity(String password) {
        return password.length() > 8 && isUpperCase(password) && isDigit(password) && isSymbol(password);
    }

    static boolean isUpperCase(String password) {
        for (char c : allLetters.toCharArray()) {
            if (password.contains(Character.toString(c))) {
                return true;
            }
        }
        return false;
    }

    static boolean isDigit(String text) {
        for (char d : allDigits.toCharArray()) {
            if (text.contains(Character.toString(d))) {
                return true;
            }
        }
        return false;
    }

    static boolean isSymbol(String password) {
        for (char c : password.toCharArray()) {
            if (!Character.isLetterOrDigit(c)) {
                return true;
            }
        }
        return false;
    }

    static boolean checkCellphoneNumber(String number) {
        return number.startsWith("+27") && number.length() == 12;
    }

    static void registerUser() {
        do {
            setRegistrationUsername = JOptionPane.showInputDialog("Enter Username:");
        } while (!checkUsername(setRegistrationUsername));

        do {
            setRegistrationPassword = JOptionPane.showInputDialog("Enter Password:");
        } while (!checkPasswordComplexity(setRegistrationPassword));

        do {
            setRegistrationNumber = JOptionPane.showInputDialog("Enter Cellphone Number:");
        } while (!checkCellphoneNumber(setRegistrationNumber));

        JOptionPane.showMessageDialog(null, "Registration successful!");
    }

    static boolean loginUser() {
        String username = JOptionPane.showInputDialog("Login - Enter Username:");
        String password = JOptionPane.showInputDialog("Login - Enter Password:");
        return username.equals(setRegistrationUsername) && password.equals(setRegistrationPassword);
    }

    // -------- MESSAGE CLASS BELOW --------

    static class Message {
        private String messageID;
        private String recipientCell;
        private String messageContent;
        private String messageHash;

        private static final List<Message> messagesSent = new ArrayList<>();

        public Message(String messageID, String recipientCell, String messageContent) {
            this.messageID = messageID;
            this.recipientCell = recipientCell;
            this.messageContent = messageContent;
            this.messageHash = createMessageHash();
        }

        public boolean checkMessageID() {
            return messageID != null && messageID.length() <= 10;
        }

        public boolean checkRecipientCell() {
            return recipientCell != null && recipientCell.length() <= 15 && recipientCell.matches("\\+\\d+");
        }

        public boolean checkMessageLength() {
            return messageContent != null && messageContent.length() <= 250;
        }

        public String createMessageHash() {
            return UUID.randomUUID().toString().substring(0, 8);
        }

        public String sendMessage() {
            return "Message Sent: " + messageContent;
        }

        public static void storeMessage(Message message) {
            messagesSent.add(message);
        }

        public static List<Message> getMessagesSent() {
            return messagesSent;
        }

        public String getMessageID() {
            return messageID;
        }

        public String getRecipientCell() {
            return recipientCell;
        }

        public String getMessageContent() {
            return messageContent;
        }

        public String getMessageHash() {
            return messageHash;
        }
    }

    // -------- MAIN METHOD BELOW --------

    public static void main(String[] args) {
        registerUser();
        if (loginUser()) {
            JOptionPane.showMessageDialog(null, "✅ Login successful. Welcome " + setRegistrationUsername + "!");
            SwingUtilities.invokeLater(QuickChatApp::new);
        } else {
            JOptionPane.showMessageDialog(null, "❌ Login failed. Please try again.");
                    }
               
    }
    
}


    

